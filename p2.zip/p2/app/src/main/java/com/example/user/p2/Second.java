package com.example.user.p2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Second extends AppCompatActivity {
    Button btn,btn1,btn2,btn3,btn4;
    EditText edit,edit2;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        btn=(Button) findViewById(R.id.button2);
        btn1=(Button) findViewById(R.id.button3);
        btn2=(Button) findViewById(R.id.button4);
        btn3=(Button) findViewById(R.id.button6);
        btn4=(Button) findViewById(R.id.button7);
        edit=(EditText) findViewById(R.id.edit);
        edit2=(EditText) findViewById(R.id.editText);
        text=(TextView) findViewById(R.id.textView);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one=edit.getText().toString();
                String two=edit2.getText().toString();
                int a=Integer.parseInt(one);
                int b=Integer.parseInt(two);
                int c=a+b;
                text.setText(Integer.toString(c));
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one=edit.getText().toString();
                String two=edit2.getText().toString();
                int a=Integer.parseInt(one);
                int b=Integer.parseInt(two);
                int c=a-b;
                text.setText(Integer.toString(c));
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one=edit.getText().toString();
                String two=edit2.getText().toString();
                int a=Integer.parseInt(one);
                int b=Integer.parseInt(two);
                try {
                    int c = a / b;
                    text.setText(Integer.toString(c));
                }
                catch (Exception e){
                    Toast.makeText(getApplicationContext(),"cannot divide by zero",Toast.LENGTH_SHORT).show();
                }


                }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one=edit.getText().toString();
                String two=edit2.getText().toString();
                int a=Integer.parseInt(one);
                int b=Integer.parseInt(two);
                int c=a*b;
                text.setText(Integer.toString(c));
            }
        });





    }
}
